import React from "react";
import { useNavigate } from "react-router-dom";
import "./CoverPage.css";

export default function CoverPage() {
  const navigate = useNavigate();

  const handleStart = () => {
    navigate("/volunteerlogin"); // navigate to volunteer login page
  };

  return (
    <div className="cover-container">
        <img src="https://touchalifeorg.com/wp-content/uploads/2025/04/logo-e1745902555693.png" 
        alt="Touch A Life logo" class="logo" loading="lazy" width="400" height="120" />
      <h1>Touch A Life Foundation</h1>
      <h3>Touching Lives Since 2014</h3>
      <p>Welcome! Click below to continue as Volunteer</p>
      <button onClick={handleStart}>VOLUNTEER</button>
    </div>
  );
}