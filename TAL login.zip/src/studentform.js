import React, { useState, useEffect } from "react";
import "./StudentForm.css";

export default function StudentForm() {
  const volunteer_id = localStorage.getItem("volunteer_id");

  useEffect(() => {
    if (!volunteer_id) {
      alert("Please login first");
      window.location.href = "/volunteerlogin";
    }
  }, [volunteer_id]);

  const [formData, setFormData] = useState({
  full_name: "",
  age: "",
  email: "",
  contact_no: "",
  whatsapp_no: "",
  parent_no: "",
  family_members: "",
  parents_names: "",
  earning_members: "",
  school_college: "",
  branch: "",
  previous_percentage: "",
  present_percentage: "",
  course_class_fee: "",
  job_details: "",
  aspiration: "",
  scholarship_details: "",

  // 🆕 New fields
  achievement_certificates: "",
  present_scholarship_details: "",
  years_in_area: "",
  scholarship_reason: ""
});
  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = { volunteer_id, ...formData };
      const res = await fetch("http://localhost:4000/student", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        window.location.href = `/studentdocs?student_id=${data.student_id}`;
      } else {
        alert("⚠️ " + (data.message || "Failed to save student"));
      }
    } catch (err) {
      console.error("Student submit error:", err);
      alert("❌ Could not reach server.");
    }
  };

  return (
    <div className="form-container">
      <h2 className="form-title">Student Details — Page 1</h2>
      <form onSubmit={handleSubmit} className="form-grid">
        {/* Personal Details */}
        <div className="form-section">
          <h3>👤 Personal Details</h3>
          <label>Full Name</label>
          <input type="text" name="full_name" value={formData.full_name} onChange={handleChange} required />

          <label>Age</label>
          <input type="text" name="age" value={formData.age} onChange={handleChange} />

          <label>Email</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} required />

          <label>Contact Number</label>
          <input type="text" name="contact_no" value={formData.contact_no} onChange={handleChange} />

          <label>WhatsApp Number</label>
          <input type="text" name="whatsapp_no" value={formData.whatsapp_no} onChange={handleChange} />

          <label>Parent Number</label>
          <input type="text" name="parent_no" value={formData.parent_no} onChange={handleChange} />

          <label>Family Members</label>
          <input type="text" name="family_members" value={formData.family_members} onChange={handleChange} />

          <label>Parents Names</label>
          <input type="text" name="parents_names" value={formData.parents_names} onChange={handleChange} />

          <label>Earning Members</label>
          <input type="text" name="earning_members" value={formData.earning_members} onChange={handleChange} />
        </div>

        {/* Academic Details */}
        <div className="form-section">
          <h3>📚 Academic Details</h3>
          <label>School / College</label>
          <input type="text" name="school_college" value={formData.school_college} onChange={handleChange} />

          <label>Branch</label>
          <input type="text" name="branch" value={formData.branch} onChange={handleChange} />

          <label>Previous Percentage</label>
          <input type="text" name="previous_percentage" value={formData.previous_percentage} onChange={handleChange} />

          <label>Present Percentage</label>
          <input type="text" name="present_percentage" value={formData.present_percentage} onChange={handleChange} />
        </div>

        {/* Other Details */}
        <div className="form-section">
          <h3>📌 Other Details</h3>
          <label>Course/Class Fee</label>
          <input type="text" name="course_class_fee" value={formData.course_class_fee} onChange={handleChange} />

          <label>Job Details</label>
          <input type="text" name="job_details" value={formData.job_details} onChange={handleChange} />

          <label>Aspiration</label>
          <input type="text" name="aspiration" value={formData.aspiration} onChange={handleChange} />

          <label>Scholarship Details</label>
          <input type="text" name="scholarship_details" value={formData.scholarship_details} onChange={handleChange} />

          <label>Achievement Certificates</label>
<input
  type="text"
  name="achievement_certificates"
  value={formData.achievement_certificates}
  onChange={handleChange}
/>

<label>Present Scholarship Details</label>
<input
  type="text"
  name="present_scholarship_details"
  value={formData.present_scholarship_details}
  onChange={handleChange}
/>

<label>Years Living in Area</label>
<input
  type="text"
  name="years_in_area"
  value={formData.years_in_area}
  onChange={handleChange}
/>

<label>Reason for Scholarship</label>
<textarea
  name="scholarship_reason"
  value={formData.scholarship_reason}
  onChange={handleChange}
/>
        </div>
      </form>

      <div className="submit-container">
        <button type="submit" className="btn-primary">Next: Document Collection</button>
      </div>
    </div>
  );
}
