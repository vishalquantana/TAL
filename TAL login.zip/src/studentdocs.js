// studentdocs.js
import React, { useState } from "react";
import "./StudentForm.css";
export default function StudentDocs() {
  const params = new URLSearchParams(window.location.search);
  const student_id = params.get("student_id");

  const [docs, setDocs] = useState({
    school_id_collected: "N",
    fees_receipt_collected: "N",
    aadhaar_collected: "N",
    income_proof_collected: "N",
    marksheets_collected: "N",
    fees_transfer_details: "",
    bank_account_details: "",
    passport_photo_collected: "N",
    volunteer_verification: "",
    volunteer_signature: "",
    girl_verification: "",
    girl_signature: "",
    parent_signature: ""
  });

  const handleChange = (e) => {
    const { name, type, checked, value } = e.target;
    setDocs({ ...docs, [name]: type === "checkbox" ? (checked ? "Y" : "N") : value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!student_id) return alert("Missing student_id — go back to page 1.");

    try {
      const payload = { student_id, ...docs };
      const res = await fetch("http://localhost:4000/studentdocs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        alert("✅ Student and document info saved successfully!");
        // optional: redirect to a thank-you page or clear localStorage
        window.location.href = "/studentform";
      } else {
        alert("⚠️ " + (data.message || "Failed to save documents"));
      }
    } catch (err) {
      console.error("Student docs error:", err);
      alert("❌ Could not reach server");
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: 700, margin: "20px auto", padding: 20 }}>
      <h2>Student Documents — Page 2</h2>

      <label>
        <input type="checkbox" name="school_id_collected" onChange={handleChange} /> School ID collected
      </label>

      <label>
        <input type="checkbox" name="fees_receipt_collected" onChange={handleChange} /> Fees receipt collected
      </label>

      <label>
        <input type="checkbox" name="aadhaar_collected" onChange={handleChange} /> Aadhaar collected
      </label>

      <label>
        <input type="checkbox" name="income_proof_collected" onChange={handleChange} /> Income proof collected
      </label>

      <label>
        <input type="checkbox" name="marksheets_collected" onChange={handleChange} /> Marksheets collected
      </label>

      <input name="fees_transfer_details" placeholder="Fees transfer details" onChange={handleChange} />
      <input name="bank_account_details" placeholder="Bank account details" onChange={handleChange} />

      <label>
        <input type="checkbox" name="passport_photo_collected" onChange={handleChange} /> Passport photo collected
      </label>

      {/* volunteer_verification / signatures - simple text fields for now */}
      <input name="volunteer_verification" placeholder="Volunteer verification (notes)" onChange={handleChange} />
      <input name="volunteer_signature" placeholder="Volunteer signature (name)" onChange={handleChange} />
      <input name="girl_verification" placeholder="Girl verification (notes)" onChange={handleChange} />
      <input name="girl_signature" placeholder="Girl signature (name)" onChange={handleChange} />
      <input name="parent_signature" placeholder="Parent signature (name)" onChange={handleChange} />

      <button type="submit" style={{ marginTop: 12 }}>Submit Student Details</button>
    </form>
  );
}
