import React, { useState } from "react";
import axios from "axios";

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:4000/register", {
        name,
        email,
        password,
      });

      if (response.data.success) {
        alert("Volunteer registered successfully! Please login now.");
        // ✅ Redirect to login page
        window.location.href = "/volunteerlogin";
      } else {
        alert(response.data.error || "Registration failed");
      }
    } catch (error) {
      console.error("❌ Registration error:", error);
      alert("Something went wrong. Please try again.");
    }
  };

  return (
    <div style={{ maxWidth: "400px", margin: "50px auto" }}>
      <h2>Volunteer Registration</h2>
      <form onSubmit={handleRegister}>
        <div>
          <label>Name: </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email: </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Password: </label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Register</button>
      </form>

      <p>
        Already registered?{" "}
        <a href="/volunteerlogin">Click here to login</a>
      </p>
    </div>
  );
}

export default Register;
