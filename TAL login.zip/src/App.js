import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import CoverPage from "./CoverPage";          // Landing page
import VolunteerLogin from "./volunteerlogin"; // Volunteer login
import Register from "./register";             // Volunteer register
import StudentForm from "./studentform";       // Student form
import StudentDocs from "./studentdocs";       // Student docs

function App() {
  return (
    <Router>
      <Routes>
        {/* Cover page shows first */}
        <Route path="/" element={<CoverPage />} />

        {/* Volunteer auth */}
        <Route path="/volunteerlogin" element={<VolunteerLogin />} />
        <Route path="/register" element={<Register />} /> {/* Register route added */}

        {/* Student flow */}
        <Route path="/studentform" element={<StudentForm />} />
        <Route path="/studentdocs" element={<StudentDocs />} />
      </Routes>
    </Router>
  );
}

export default App;
