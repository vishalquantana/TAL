import React, { useState } from 'react';
import axios from 'axios';

function StudentForm({ volunteerId }) {
  const [studentData, setStudentData] = useState({
    full_name: '',
    age: '',
    email: '',
    contact_no: '',
    whatsapp_no: '',
    parent_no: '',
    family_members: '',
    parents_names: '',
    earning_members: '',
    school_college: '',
    branch: '',
    previous_percentage: '',
    present_percentage: '',
    course_class_fee: '',
    job_details: '',
    aspiration: '',
    scholarship_details: '',
    school_id_collected: 'N',
    fees_receipt_collected: 'N',
    aadhaar_collected: 'N',
    income_proof_collected: 'N',
    marksheets_collected: 'N',
    fees_transfer_details: '',
    bank_account_details: '',
    passport_photo_collected: 'N',
    volunteer_verification: '',
    volunteer_signature: '',
    girl_verification: '',
    girl_signature: '',
    parent_signature: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudentData({ ...studentData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:3001/student/add', {
        volunteer_id: volunteerId,
        ...studentData
      });
      if (res.data.success) {
        alert('Student added successfully!');
        setStudentData({ ...studentData, full_name: '', email: '' }); // reset form partially
      }
    } catch (err) {
      console.error(err);
      alert('Error adding student');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Student Information</h2>
      <input name="full_name" placeholder="Full Name" value={studentData.full_name} onChange={handleChange} required />
      <input name="age" type="number" placeholder="Age" value={studentData.age} onChange={handleChange} required />
      <input name="email" placeholder="Email" value={studentData.email} onChange={handleChange} required />
      <input name="contact_no" placeholder="Contact No" value={studentData.contact_no} onChange={handleChange} />
      <input name="whatsapp_no" placeholder="Whatsapp No" value={studentData.whatsapp_no} onChange={handleChange} />
      <input name="parent_no" placeholder="Parent No" value={studentData.parent_no} onChange={handleChange} />
      <input name="family_members" placeholder="Family Members" value={studentData.family_members} onChange={handleChange} />
      <input name="parents_names" placeholder="Parents Names" value={studentData.parents_names} onChange={handleChange} />
      <input name="earning_members" placeholder="Earning Members" value={studentData.earning_members} onChange={handleChange} />
      <input name="school_college" placeholder="School/College" value={studentData.school_college} onChange={handleChange} />
      <input name="branch" placeholder="Branch" value={studentData.branch} onChange={handleChange} />
      <input name="previous_percentage" type="number" step="0.01" placeholder="Previous %age" value={studentData.previous_percentage} onChange={handleChange} />
      <input name="present_percentage" type="number" step="0.01" placeholder="Present %age" value={studentData.present_percentage} onChange={handleChange} />
      <input name="course_class_fee" placeholder="Course/Class Fee" value={studentData.course_class_fee} onChange={handleChange} />
      <input name="job_details" placeholder="Job Details" value={studentData.job_details} onChange={handleChange} />
      <input name="aspiration" placeholder="Aspiration" value={studentData.aspiration} onChange={handleChange} />
      <input name="scholarship_details" placeholder="Scholarship Details" value={studentData.scholarship_details} onChange={handleChange} />

      <h2>Document & Verification</h2>
      <select name="school_id_collected" value={studentData.school_id_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <select name="fees_receipt_collected" value={studentData.fees_receipt_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <select name="aadhaar_collected" value={studentData.aadhaar_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <select name="income_proof_collected" value={studentData.income_proof_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <select name="marksheets_collected" value={studentData.marksheets_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <input name="fees_transfer_details" placeholder="Fees Transfer Details" value={studentData.fees_transfer_details} onChange={handleChange} />
      <input name="bank_account_details" placeholder="Bank Account Details" value={studentData.bank_account_details} onChange={handleChange} />
      <select name="passport_photo_collected" value={studentData.passport_photo_collected} onChange={handleChange}>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
      <input name="volunteer_verification" placeholder="Volunteer Verification" value={studentData.volunteer_verification} onChange={handleChange} />
      <input name="volunteer_signature" placeholder="Volunteer Signature" value={studentData.volunteer_signature} onChange={handleChange} />
      <input name="girl_verification" placeholder="Girl Verification" value={studentData.girl_verification} onChange={handleChange} />
      <input name="girl_signature" placeholder="Girl Signature" value={studentData.girl_signature} onChange={handleChange} />
      <input name="parent_signature" placeholder="Parent Signature" value={studentData.parent_signature} onChange={handleChange} />

      <button type="submit">Submit Student</button>
    </form>
  );
}

export default StudentForm;
