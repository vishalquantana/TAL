import React, { useState } from "react";
import axios from "axios";

function App() {
  const [registerData, setRegisterData] = useState({ name: "", email: "", password: "" });
  const [loginData, setLoginData] = useState({ email: "", password: "" });

  const handleRegister = async () => {
    try {
      const res = await axios.post("http://localhost:5000/register", registerData);
      alert(res.data.message);
    } catch (err) {
      alert("Error registering!");
    }
  };

  const handleLogin = async () => {
    try {
      const res = await axios.post("http://localhost:5000/login", loginData);
      alert(res.data.message);
    } catch (err) {
      alert("Login failed ❌");
    }
  };

  return (
    <div>
      <h1>Volunteer Portal</h1>

      <h2>Volunteer Register</h2>
      <input
        type="text"
        placeholder="Name"
        value={registerData.name}
        onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
      />
      <input
        type="email"
        placeholder="Email"
        value={registerData.email}
        onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
      />
      <input
        type="password"
        placeholder="Password"
        value={registerData.password}
        onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
      />
      <button onClick={handleRegister}>Register</button>

      <h2>Volunteer Login</h2>
      <input
        type="email"
        placeholder="Email"
        value={loginData.email}
        onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
      />
      <input
        type="password"
        placeholder="Password"
        value={loginData.password}
        onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default App;
